using Microsoft.EntityFrameworkCore;
using ReadMoreBooks;

using var context = new BookStoreContext();

context.Database.Migrate();

Console.WriteLine("Can connect to database: " + context.Database.CanConnect());

if (!context.Books.Any())
{
    var category = new Category
    {
        Name = "Programming",
        Description = "Books about software development",
        IsActive = true
    };

    var author = new Author
    {
        FirstName = "Robert",
        LastName = "Martin",
        Email = "robert.martin@example.com",
        Biography = "Software engineer and author.",
        DateOfBirth = new DateTime(1952, 12, 5)
    };

    var book = new Book
    {
        Title = "Clean Code",
        ISBN = "9780132350884",
        Price = 35.50m,
        NumberOfPages = 464,
        PublishedYear = 2008,
        InStock = true,
        Author = author,
        Category = category
    };

    context.Books.Add(book);
    context.SaveChanges();
    Console.WriteLine("Sample data inserted.");
}

var books = context.Books
    .Include(b => b.Author)
    .Include(b => b.Category)
    .ToList();

foreach (var b in books)
{
    Console.WriteLine($"{b.Title} | {b.ISBN} | ${b.Price} | {b.NumberOfPages} pages | {b.PublishedYear} | InStock: {b.InStock}");
    Console.WriteLine($"   Author: {b.Author.FirstName} {b.Author.LastName} ({b.Author.Email})");
    Console.WriteLine($"   Category: {b.Category.Name} (Active: {b.Category.IsActive})");
}
